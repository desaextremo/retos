package com.desaextremo.retotres;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RetodosApplicationTests {

	@Test
	void contextLoads() {
	}

}
